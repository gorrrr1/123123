Готовый статический сайт (index.html + assets) для GitHub Pages.

Как опубликовать:
1) Распакуйте архив.
2) Создайте репозиторий на GitHub и загрузите файлы на ветку main.
3) В настройках репозитория включите Pages: Source → Deploy from a branch → main / root.
4) Откройте выданный GitHub Pages URL.